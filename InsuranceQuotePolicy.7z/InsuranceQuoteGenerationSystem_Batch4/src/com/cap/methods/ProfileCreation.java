package com.cap.methods;

import java.util.Scanner;

import com.cap.Bean.UserRole;
import com.cap.exception.IQPException;
import com.cap.serviceInterface.InsuranceService;
import com.cap.serviceValidation.InsuranceServiceImpl;

public class ProfileCreation {

	
	public void profileCreation() throws IQPException{
		
		InsuranceService service=new InsuranceServiceImpl();
		Scanner scanner=null;
		String userName="";
		String password="";
		String userRole="";
		boolean userFlag=false;
		boolean passwordFlag=false;
		boolean userRoleFlag=false;
		
		do {
			scanner=new Scanner(System.in);
			System.out.println("Enter user name: ");
			userName=scanner.nextLine();
			try {
				boolean validUserName=service.checkUserName(userName);
				if(validUserName==true) {
					userFlag=true;
				}
			} catch (IQPException e) {
				System.err.println(e.getMessage());
				userFlag=false;
			}
			
		}while(!userFlag);
		
		do {
			scanner=new Scanner(System.in);
			System.out.println("Enter password: ");
			password=scanner.nextLine();
			try {
				boolean validPassword=service.checkPassword(password);
				if(validPassword==true) {
					passwordFlag=true;
				}
			}catch (IQPException e) {
				System.err.println(e.getMessage());
				passwordFlag=false;
			}
		}while(!passwordFlag);
		
		do {
			scanner=new Scanner(System.in);
			System.out.println("Enter user role: ");
			userRole=scanner.next();
			try {
				boolean validUserRole=service.checkUserRole(userRole);
				if(validUserRole==true) {
					userRoleFlag=true;
				}
			} catch (IQPException e) {
				System.err.println(e.getMessage());
				userRoleFlag=false;
			}
		}while(!userRoleFlag);
		
		UserRole role=new UserRole(userName, password, userRole);
		try {
			int record=service.addProfile(role);
			System.out.println(record+" profile inserted.");
		}catch (IQPException e) {
			System.err.println(e.getMessage());
		}
					catch (Exception e) {
		// TODO: handle exception
			System.out.println("error");
		}
		
		//scanner.close();
		
	}

}
