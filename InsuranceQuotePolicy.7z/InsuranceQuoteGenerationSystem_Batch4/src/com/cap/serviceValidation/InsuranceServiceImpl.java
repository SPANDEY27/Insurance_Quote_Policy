package com.cap.serviceValidation;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.cap.Bean.Accounts;
import com.cap.Bean.Policy;
import com.cap.Bean.PolicyDetails;
import com.cap.Bean.ReportGeneration;
import com.cap.Bean.UserRole;
import com.cap.DAO.InsuranceServiceDao;
import com.cap.DAOImp.InsuranceServiceDaoImpl;
import com.cap.exception.IQPException;
import com.cap.serviceInterface.InsuranceService;

public class InsuranceServiceImpl implements InsuranceService {

	InsuranceServiceDao dao = new InsuranceServiceDaoImpl();

	@Override
	public String validUser(UserRole role) throws IQPException {

		return dao.validLogIn(role);
	}

	/*@Override
	public int createAccount(Accounts accounts) throws IQPException {
		// TODO Auto-generated method stub
		//return dao.createAccount(accounts);
	}*/

	@Override
	public boolean validFields(Accounts accounts) throws IQPException {
		List<String> list = new ArrayList<>();
		boolean vFlag = false;
		if(!validName(accounts.getInsuredName()))
		{
			list.add("First letter of name should be capital and maximum limit is 30");
		}
		if(!validStreet(accounts.getInsuredStreet()))
		{
			list.add("First letter of street should be capital!!");
		}
		if(!validCity(accounts.getInsuredCity()))
		{
			list.add("First letter of city should be capital!!");
		}
		if(!validState(accounts.getInsuredState()))
		{
			list.add("First letter of state should be capital!!");
		}
		if(!validZip(accounts.getInsuredZip()))
		{
			list.add("Zip should be a 5 digit number!!!!!!!");
		}
		if(!validBisSeg(accounts.getBusinessSegment()))
		{
			list.add("First letter of Business segment should be capital!!");
		}
		if(!list.isEmpty())
		{
			throw new IQPException(list+ "");
		}
		else
		{
			vFlag = true;
		}
		
		return vFlag;
	}

	public boolean validName(String name) {
		String nameCheck = "[A-Z]{1}[A-Za-z ]{2,29}";
		return Pattern.matches(nameCheck, name);
	}

	public boolean validStreet(String street) 
	{
		String streetCheck = "[A-Z]{1}[A-Za-z]{2,39}";
		return Pattern.matches(streetCheck, street);
	}

	public boolean validCity(String city) 
	{
		String cityCheck = "[A-Z]{1}[A-Za-z]{2,14}";
		return Pattern.matches( cityCheck,city);
	}

	public boolean validState(String  state) {
		String stateCheck = "[A-Z]{1}[A-Za-z]{2,14}";
		return Pattern.matches(stateCheck,state);

	}
	public boolean validZip(int zip) {
		String zipCheck = "[0-9]{5}";
		return Pattern.matches(zipCheck, Integer.toString(zip));
	}
	public boolean validBisSeg(String bisSeg) {
		String BisSegCheck = "[A-Z]{1}[A-Za-z ]{2,14}";
		return Pattern.matches(BisSegCheck,bisSeg);
	}

	@Override
	public int createAccount(Accounts accounts) throws IQPException {
		
		return dao.createAccount(accounts);
	}

	@Override
	public boolean getUserName(String userName) throws IQPException {
		
		return dao.getUserName(userName);
	}

	@Override
	public boolean checkUserName(String userName) throws IQPException {
		String userNameCheck="[a-z0-9]{3,20}";
		if(Pattern.matches(userNameCheck, userName)) {
			return true;
		}else {
			throw new IQPException("Username must contain letters and digits . No capital letters allowed !!");
		}
	}

	@Override
	public boolean checkPassword(String password) throws IQPException {
		String passwordRegEx="[a-zA-Z0-9]{3,12}";
		if(Pattern.matches(passwordRegEx, password)) {
			return true;
		}else {
			throw new IQPException("Password must contain letters and digits . Size must be greater then 3");
		}
	}

	@Override
	public boolean checkUserRole(String userRole) throws IQPException {
		boolean uflag=false;
		if(userRole.equals("Insured")||userRole.equals("Agent")||userRole.equals("Admin")) {
			uflag=true;
			return uflag;
		}else {
			throw new IQPException("User role must be Agent or Insured or Admin");
		}
		
	}

	@Override
	public int addProfile(UserRole role) throws IQPException {
		
		return dao.addProfile(role);
	}

	@Override
	public int createPolicy(int account) throws IQPException {
		// TODO Auto-generated method stub
		//return dao.createPolicy();
		return 0;
	}

	@Override
	public boolean validAccountNumber(int accountNumber) throws IQPException {
		String accountCheck="[0-9]{7}";
		return Pattern.matches(accountCheck, Integer.toString(accountNumber));
	}

	@Override
	public boolean existAccount(int accountNumber) throws IQPException {
		
		return dao.existAccount(accountNumber);
	}

	@Override
	public String getBuisnessSegment(int accountNumber) throws IQPException {
		
		return dao.getBuisnessSegment(accountNumber);
	}

	@Override
	public String getBuisnessSegmentId(String businessSegment) throws IQPException {
		
		return dao.getBuisnessSegmentId(businessSegment);
	}

	@Override
	public List<String> getQuestions(String buisnessSegId) throws IQPException {
		
		return dao.getQuestions(buisnessSegId);
	}

	@Override
	public List<String> getAnswer(String string) throws IQPException {
		
		return dao.getAnswer(string);
	}

	

	@Override
	public int getWeightage(String string,String option) throws IQPException {
		
		return dao.getWeightage(string,option);
	}

	@Override
	public int insertPolicy(Policy policy) throws IQPException {
		return dao.insertPolicy(policy);
	}

	@Override
	public String getQuesId(String question) throws IQPException {
		
		return dao.getQuesId(question);
	}

	@Override
	public List<String> getQuestionId(String buisnessSegId) throws IQPException {
		
		return dao.getQuestionId(buisnessSegId);
	}

	@Override
	public void insertPolicyDetails(PolicyDetails policyDetails) throws IQPException {
		dao.insertPolicyDetails(policyDetails);
		
	}

	@Override
	public List<Policy> viewPolicyDetails() throws IQPException {
		
		return dao.viewPolicyDetails();
	}

	@Override
	public List<ReportGeneration> generateReport(int accountNumber1) throws IQPException {
		
		return dao.generateReport(accountNumber1);
	}

	@Override
	public Policy getPolicy(String userName) throws IQPException {
		
		return dao.getPolicy(userName);
	}

	

}
